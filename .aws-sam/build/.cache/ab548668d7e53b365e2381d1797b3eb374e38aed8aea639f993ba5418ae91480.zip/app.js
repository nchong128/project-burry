const NotionTableId = process.env.SHOPPING_LIST_TABLE_ID;

exports.handler = async function(event) {
    console.log("Hello World!");
    console.log(event);
}